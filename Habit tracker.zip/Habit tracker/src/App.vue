<!-- src/App.vue -->
<template>
  <div id="app">
    <nav class="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/habits">Habits</router-link> |
      <router-link to="/dashboard">Dashboard</router-link> |
      <router-link to="/login">Login</router-link>
    </nav>

    <main class="main">
      <router-view />
    </main>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
#app { padding: 16px; }
.nav { margin-bottom: 16px; }
.main { padding: 8px; border-radius: 6px; }
</style>
