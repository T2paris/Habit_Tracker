import { createRouter, createWebHistory } from 'vue-router'
import Home from '../pages/Home.vue'
import Login from '../pages/Login.vue'
import Habits from '../pages/Habits.vue'
import Dashboard from '../pages/Dashboard.vue'
import { useUserStore } from '../stores/user'

const routes = [
  { path: '/', component: Home },
  { path: '/login', component: Login },
  { path: '/habits', component: Habits, meta: { requiresAuth: true } },
  { path: '/dashboard', component: Dashboard, meta: { requiresAuth: true } }
]

export const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const userStore = useUserStore()

  userStore.load()

  if (to.meta.requiresAuth && !userStore.isLoggedIn) {
    return next('/login')
  }

  next()
})
