<!-- src/pages/Habits.vue -->
<template>
  <div>
    <h2>Habits</h2>

    <HabitForm :edit="editing" @submit="onSubmit" />

    <HabitList
      :habits="habits"
      @edit="startEdit"
      @delete="onDelete"
      @toggle="onToggleComplete"
    />
  </div>
</template>

<script>
import { onMounted, ref } from 'vue'
import { useHabitsStore } from '../stores/habits'
import { useUserStore } from '../stores/user'
import HabitForm from '../components/HabitForm.vue'
import HabitList from '../components/HabitList.vue'

export default {
  components: { HabitForm, HabitList },
  setup() {
    const habitsStore = useHabitsStore()
    const userStore = useUserStore()
    const editing = ref(null)

    onMounted(() => {
      habitsStore.load()
    })

    function onSubmit(habit) {
      if (editing.value) {
        habitsStore.updateHabit(habit.id, habit)
        editing.value = null
      } else {
        habitsStore.createHabit(habit)
      }
    }

    function startEdit(h) {
      editing.value = h
    }

    function onDelete(id) {
      habitsStore.deleteHabit(id)
    }

    function onToggleComplete(id) {
      const today = new Date().toISOString().slice(0,10)
      const before = habitsStore.habits.find(h => h.id === id)
      const completedBefore = before?.completedDates?.includes(today)
      habitsStore.toggleComplete(id, today)

      // dar XP apenas quando marca como COMPLETADO (não quando desmarca)
      if (!completedBefore) {
        userStore.addXP(10)
      }
    }

    return {
      habits: habitsStore.habits,
      editing,
      onSubmit,
      startEdit,
      onDelete,
      onToggleComplete
    }
  }
}
</script>
