<template>
  <div>
    <h2>Login</h2>

    <form @submit.prevent="loginUser">
      <input v-model="name" placeholder="Nome" required />
      <button type="submit">Entrar</button>
    </form>

    
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useUserStore } from "../stores/user";
import { useRouter } from "vue-router";

const name = ref("");
const userStore = useUserStore();
const router = useRouter();

function loginUser() {
  userStore.login(name.value);
  router.push("/dashboard");
}
</script>
