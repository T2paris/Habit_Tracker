<!-- src/pages/Dashboard.vue -->
<template>
  <div>
    <h2>Dashboard</h2>
    <p>Usuário: {{ user.name || 'Guest' }}</p>
    <p>Sequencia: {{ user.xp }} — Level: {{ user.level }}</p>
    <p>Hábitos completados hoje: {{ completedToday }}</p>
    <div>
      <h3>Estatísticas rápidas</h3>
      <ul>
        <li>Total hábitos: {{ totalHabits }}</li>
        <li>Completados hoje: {{ completedToday }}</li>
      </ul>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue'
import { useUserStore } from '../stores/user'
import { useHabitsStore } from '../stores/habits'

export default {
  setup() {
    const user = useUserStore()
    const habits = useHabitsStore()
    habits.load()

    const totalHabits = computed(() => habits.habits.length)
    const completedToday = computed(() => {
      const today = new Date().toISOString().slice(0,10)
      return habits.habits.filter(h => h.completedDates.includes(today)).length
    })

    return { user, totalHabits, completedToday }
  }
}
</script>
