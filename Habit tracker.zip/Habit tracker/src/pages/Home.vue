<!-- src/pages/Home.vue -->
<template>
  <div>
    <h1>Welcome to Habit Tracker</h1>
    <p>Rápido: cria hábitos ao completá-los e começe a sequência.</p>
  </div>
</template>

<script>
export default { name: 'Home' }
</script>
