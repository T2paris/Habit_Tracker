// src/stores/habits.js
import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useHabitsStore = defineStore('habits', {
  state: () => ({
    habits: []
  }),

  actions: {
    load() {
      const raw = localStorage.getItem('habits')
      this.habits = raw ? JSON.parse(raw) : []
    },

    save() {
      localStorage.setItem('habits', JSON.stringify(this.habits))
    },

    createHabit(habit) {
      // habit: { id, title, description, frequency }
      this.habits.push({ ...habit, completedDates: [] })
      this.save()
    },

    updateHabit(id, updates) {
      const i = this.habits.findIndex(h => h.id === id)
      if (i !== -1) {
        this.habits[i] = { ...this.habits[i], ...updates }
        this.save()
      }
    },

    deleteHabit(id) {
      this.habits = this.habits.filter(h => h.id !== id)
      this.save()
    },

    toggleComplete(id, date = new Date().toISOString().slice(0,10)) {
      const h = this.habits.find(h => h.id === id)
      if (!h) return
      const idx = h.completedDates.indexOf(date)
      if (idx === -1) {
        h.completedDates.push(date)
      } else {
        h.completedDates.splice(idx, 1)
      }
      this.save()
    },

    completedTodayCount() {
      const today = new Date().toISOString().slice(0,10)
      return this.habits.filter(h => h.completedDates.includes(today)).length
    }
  }
})
