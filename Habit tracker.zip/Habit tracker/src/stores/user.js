import { defineStore } from "pinia";

export const useUserStore = defineStore("user", {
  state: () => ({
    name: null,
    isLoggedIn: false,
    xp: 0,
    level: 1,
  }),

  actions: {
    login(name) {
      this.name = name;
      this.isLoggedIn = true;
      localStorage.setItem("user", JSON.stringify(this.$state));
    },

    logout() {
      this.name = null;
      this.isLoggedIn = false;
      this.xp = 0;
      this.level = 1;
      localStorage.removeItem("user");
    },

    addXP(amount = 10) {
      this.xp += amount;
      const xpForNext = this.level * 100;

      if (this.xp >= xpForNext) {
        this.xp -= xpForNext;
        this.level++;
      }

      localStorage.setItem("user", JSON.stringify(this.$state));
    },

    load() {
      const saved = localStorage.getItem("user");
      if (saved) {
        Object.assign(this, JSON.parse(saved));
      }
    }
  },
});
